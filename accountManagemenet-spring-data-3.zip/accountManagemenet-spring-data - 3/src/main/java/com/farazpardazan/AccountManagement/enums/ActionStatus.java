package com.farazpardazan.AccountManagement.enums;

public enum ActionStatus {
    Fail,
    Successful
}
